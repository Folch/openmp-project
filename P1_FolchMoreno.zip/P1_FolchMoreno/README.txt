Per tal de compilar el programa, s'ha d'obrir el projecte amb Qt-creator. Aquest ja està configurat per tal d'executar-se amb les llibreries d'OpenMP i OpenCV lincades.
Només s'haurà de fer un build i després un run. És probable que el primer cop que s'obri el projecte, et demani que es configuri el projecte, només s'haurà de donar a: 'configure project' i Qt-creator ho farà automàticament.
