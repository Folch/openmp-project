#ifndef QUICKSORT_H
#define QUICKSORT_H


void quicksort(int *idx, double *compares, int len);



#endif // QUICKSORT_H

